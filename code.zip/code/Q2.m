% ELEC 4700 Assignment 2 Q2
% Liam Anderson 100941879
% Submission February 23 2020

global C


% using constants from tjsssmy 4700 code
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability

% 3/2 ratio for L/W
L = 60;
W = 40;
 
G = sparse(L*W,L*W);
d = 1;       
V = zeros(L*W,1);

conductivity = zeros(L,W);

sigout = 1;
sigin = 1e-2;

% box locations
x_box = L/3;
y_box = W/3;

% ~~~ PART A ~~~

for i=1:nx
    for j=1:ny
        n = j + (i-1)*ny; % MAPPING
        % BOUNDARY CONDITIONS
        if (i == 1)
            G(n,n) = 1;
            V(n) = 1;
            conductivity(i,j) = sigout;
        elseif (i == L)
            G(n,n) = 1;
            V(n) = 0;
            conductivity(i,j) = sigin;
        elseif (j == 1 || j == W) % EDGES
            G(n,n) = -3;
            if (i < x_box && i > x_box) % outside the box
                conductivity(i,j) = sigout;
                G(n,n-1) = sigout;
                G(n,n+1) = sigout;
                G(n-1,n) = sigout;
                G(n+1,n) = sigout;
            else % inside the box
                conductivity(i,j) = sigin;
                G(n,n-1) = sigin;
                G(n,n+1) = sigin;
                G(n-1,n) = sigin;
                G(n+1,n) = sigin;
            end
        else
            G(n,n) = -4;
            if (i < x_box && i > x_box) % outside the box
                conductivity(i,j) = sigout;
                G(n,n-1) = sigout;
                G(n,n+1) = sigout;
                G(n-1,n) = sigout;
                G(n+1,n) = sigout;
            else % inside the box
                conductivity(i,j) = sigin;
                G(n,n-1) = sigin;
                G(n,n+1) = sigin;
                G(n-1,n) = sigin;
                G(n+1,n) = sigin;
            end          
            
        end
        
    end
    
end

F = G\V;

Fnew = zeros(L*W,L*W);

for (i=1:L)
    for (j=1:W)
        n = j + (i-1)*W;
        Fnew(i,j) = F(n);
    end
end

figure(1);
surf(conductivity);
title('sigma plot');

figure(2);
surf(Fnew);
title('Voltage');

[E_x, E_y] = gradient(Fnew); % see PA session to fix

figure(3);
surf(E_x);
title('E_x');

figure(4);
surf(E_y);
title('E_y');

% Jflow = conductivity*Fnew;

figure(5);
% surf(Jflow);
title('Current flow');


% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


% ~~~ PART B ~~~



% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


% ~~~ PART C ~~~



% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


% ~~~ PART D ~~~



% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~