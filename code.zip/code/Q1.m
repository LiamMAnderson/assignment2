% ELEC 4700 Assignment 2 Q1
% Liam Anderson 100941879
% Submission February 23 2020

global C


% using constants from tjsssmy 4700 code
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability

% 3/2 ratio for L/W
L = 60;
W = 40;


% ~~~ PART A ~~~

G = sparse(L*W,L*W);
d = 1;       
V = zeros(L*W,1);

nx = L;
ny = W;

IC = 1; % INITIAL CONDITION

for i=1:nx
    for j=1:ny
        G(i,j) = 0;
    end
end


for i=1:nx
    for j=1:ny
        n = j + (i-1)*ny; % MAPPING
        % BOUNDARY CONDITIONS
        if (i == 1)
            G(n,n) = 1;
            V(n) = IC;
        elseif (i == L)
            G(n,n) = 1;
            V(n) = 0;
        elseif (j == 1)
            G(n,n) = -3/d; % middle value DIAGONAL
            G(n,n-1) = 1/d; % left side DIAGONAL
            G(n,n+1) = 1/d; % right side DIAGONAL
            G(n-1,n) = 1/d; % first value DIAGONAL
            G(n+1,n) = 1/d; % last value DIAGONAL
        elseif (j == W)
            G(n,n) = -3/d; % middle value DIAGONAL
            G(n,n-1) = 1/d; % left side DIAGONAL
            G(n,n+1) = 1/d; % right side DIAGONAL
            G(n-1,n) = 1/d; % first value DIAGONAL
            G(n+1,n) = 1/d; % last value DIAGONAL
        else
            G(n,n) = -4/d; % middle value DIAGONAL
            G(n,n-1) = 1/d; % left side DIAGONAL
            G(n,n+1) = 1/d; % right side DIAGONAL
            G(n-1,n) = 1/d; % first value DIAGONAL
            G(n+1,n) = 1/d; % last value DIAGONAL
            
        end
        
    end
    
end

Fnew = zeros(L,W);

F = G\V; % Pot

for (i=1:L)
    for (j=1:W)
        n = j + (i-1)*W;
        Fnew(i,j) = F(n);
    end
end

x = linspace(0,2,L); % 2:3 ratio
y = linspace(0,3,W); % 2:3 ratio

figure(1);
surf(Fnew);
title('Surface Plot: V(x,y)');

figure(2);
plot(x,Fnew);
title('2D Plot: V(x)');

% figure(3);
% mesh(y,x,Fnew);


% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


% ~~~ PART B ~~~

G2 = sparse(L*W,L*W);
d2 = 1;       
V2 = zeros(L*W,1);

for i=1:nx
    for j=1:ny
        n = j + (i-1)*ny; % MAPPING
        % BOUNDARY CONDITIONS
        if (i == 1 || i == L)
            G2(n,n) = 1;
            V2(n) = 1;
        elseif (j == 1)
            G2(n,n) = 1;
        elseif (j == W)
            G2(n,n) = 1;
        else
            G2(n,n) = -4/d; % middle value DIAGONAL
            G2(n,n-1) = 1/d; % left side DIAGONAL
            G2(n,n+1) = 1/d; % right side DIAGONAL
            G2(n-1,n) = 1/d; % first value DIAGONAL
            G2(n+1,n) = 1/d; % last value DIAGONAL
            
        end
        
    end
    
end

Fnew2 = zeros(L*W,L*W);

F2 = G2\V2; % Pot

for (i=1:L)
    for (j=1:W)
        n = j + (i-1)*W;
        Fnew2(i,j) = F(n);
    end
end

x2 = linspace(0,2,L); % 2:3 ratio
y2 = linspace(0,3,W); % 2:3 ratio

figure(3);
surf(Fnew2);

% figure(4);
% mesh(y2,x2,Fnew2);



